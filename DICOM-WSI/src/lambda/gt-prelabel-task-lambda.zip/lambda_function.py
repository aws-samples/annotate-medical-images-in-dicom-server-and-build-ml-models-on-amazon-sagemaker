import json
import boto3
import collections

def lambda_handler(event, context):
    # Event received
    print("Received event: " + json.dumps(event, indent=2))
    
    # Get StudyID
    studyID = event['dataObject']['studyID'] if "studyID" in event['dataObject'] else None

    # Get SeriesID
    seriesID = event['dataObject']['seriesID'] if "seriesID" in event['dataObject'] else None
    
    # Get labels
    print(isinstance(event['dataObject']['labels'], list))
    labels = event['dataObject']['labels'] if "labels" in event['dataObject'] else None
    
    # Build response object
    output = {
        "taskInput": {
            "studyID": studyID,
            "seriesID": seriesID,
            "labels": json.dumps(labels)
        }
    }


    print(output)

    return output